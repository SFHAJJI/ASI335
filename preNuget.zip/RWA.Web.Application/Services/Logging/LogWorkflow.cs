using Serilog;

namespace RWA.Web.Application.Services.Logging
{
    /// <summary>
    /// Typed, semantic events to make the per-run narrative readable and analyzable.
    /// </summary>
    public static class LogWorkflow
    {
        public static void StepEntered(ILogger log, string step) =>
            log.ForContext("Event","Workflow.StepEntered")
               .ForContext("Step", step)
               .Information("Step entered: {Step}", step);

        public static void StepExited(ILogger log, string step, string status) =>
            log.ForContext("Event","Workflow.StepExited")
               .ForContext("Step", step)
               .ForContext("Status", status)
               .Information("Step exited: {Step} with {Status}", step, status);

        public static void TransitionTriggered(ILogger log, string src, string trg, string dst) =>
            log.ForContext("Event","Workflow.TransitionTriggered")
               .ForContext("Source", src)
               .ForContext("Trigger", trg)
               .ForContext("Destination", dst)
               .Information("State changed: {Source} --{Trigger}--> {Destination}", src, trg, dst);

        public static void SignalRProgress(ILogger log, string channel, int processed, int total) =>
            log.ForContext("Event","Workflow.SignalRProgress")
               .ForContext("Channel", channel)
               .ForContext("Processed", processed)
               .ForContext("Total", total)
               .Information("SignalR progress {Processed}/{Total} on {Channel}", processed, total, channel);

        public static void BddMatchBatch(ILogger log, int rowsIn, int rowsMatched, double durationMs) =>
            log.ForContext("Event","Workflow.BddMatchBatch")
               .ForContext("RowsIn", rowsIn)
               .ForContext("RowsMatched", rowsMatched)
               .ForContext("DurationMs", durationMs)
               .Information("BDD matched {RowsMatched}/{RowsIn} in {DurationMs} ms", rowsMatched, rowsIn, durationMs);

        public static void TethysStatusRun(ILogger log, int candidates, int ok, int ko, int skipped, double durationMs) =>
            log.ForContext("Event","Workflow.TethysStatusRun")
               .ForContext("Candidates", candidates)
               .ForContext("Ok", ok)
               .ForContext("Ko", ko)
               .ForContext("Skipped", skipped)
               .ForContext("DurationMs", durationMs)
               .Information("Tethys run: {Ok}/{Candidates} OK, {Ko} KO, {Skipped} skipped in {DurationMs} ms",
                            ok, candidates, ko, skipped, durationMs);
    }
}
