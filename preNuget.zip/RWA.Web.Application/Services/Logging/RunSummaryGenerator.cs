using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RWA.Web.Application.Services.Logging
{
    /// <summary>
    /// Minimal summary generator: counts events and writes a simple timeline.
    /// Expand with p95, N+1, SignalR chatter as needed.
    /// </summary>
    public class RunSummaryGenerator
    {
        public async Task GenerateAsync(string runId)
        {
            var folder = Path.Combine("logs","workflows", runId);
            var jsonl = Path.Combine(folder, "workflow.jsonl");
            var summary = Path.Combine(folder, "summary.md");
            if (!File.Exists(jsonl)) return;

            var counts = new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
            var steps = new List<(DateTime ts,string evt,string? msg)>();

            foreach (var line in File.ReadLines(jsonl))
            {
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    var root = doc.RootElement;
                    var evt = root.TryGetProperty("Event", out var e) ? e.GetString() ?? "Unknown" : "Unknown";
                    var ts  = root.TryGetProperty("Timestamp", out var t) ? t.GetDateTime() : DateTime.UtcNow;
                    var msg = root.TryGetProperty("Message", out var m) ? m.GetString() : null;
                    counts[evt] = counts.TryGetValue(evt, out var n) ? n+1 : 1;
                    if (evt.StartsWith("Workflow.", StringComparison.OrdinalIgnoreCase))
                        steps.Add((ts, evt, msg));
                }
                catch { /* ignore parse errors */ }
            }

            steps.Sort((a,b) => a.ts.CompareTo(b.ts));

            var sb = new StringBuilder();
            sb.AppendLine("# Run summary");
            sb.AppendLine();
            sb.AppendLine("## Timeline");
            foreach (var s in steps)
                sb.AppendLine($"- {s.ts:O} — {s.evt} — {s.msg}");

            sb.AppendLine();
            sb.AppendLine("## Event counts");
            foreach (var kv in counts)
                sb.AppendLine($"- {kv.Key}: {kv.Value}");

            Directory.CreateDirectory(folder);
            await File.WriteAllTextAsync(summary, sb.ToString());
        }
    }
}
