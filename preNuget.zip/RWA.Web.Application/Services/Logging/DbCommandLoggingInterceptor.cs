using System;
using System.Data.Common;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Serilog;
using Serilog.Events;

namespace RWA.Web.Application.Services.Logging
{
    /// <summary>
    /// Logs DB command execution with duration and row counts; optionally samples SQL text (controlled by caller).
    /// Register as a singleton and add to DbContextOptions via AddInterceptors(...).
    /// </summary>
    public sealed class DbCommandLoggingInterceptor : DbCommandInterceptor
    {
        private readonly Random _rng = new Random();
        private readonly bool _sampleSql;
        private readonly double _sampleRate;

        public DbCommandLoggingInterceptor(bool sampleSql = false, double sampleRate = 0.02)
        {
            _sampleSql = sampleSql;
            _sampleRate = Math.Max(0.0, Math.Min(1.0, sampleRate));
        }

        public override async ValueTask<DbDataReader> ReaderExecutedAsync(DbCommand command, CommandExecutedEventData eventData, DbDataReader result, CancellationToken cancellationToken = default)
        {
            LogDb(eventData, command, Rows(result));
            return await base.ReaderExecutedAsync(command, eventData, result, cancellationToken);
        }

        public override async ValueTask<object> ScalarExecutedAsync(DbCommand command, CommandExecutedEventData eventData, object result, CancellationToken cancellationToken = default)
        {
            LogDb(eventData, command, null);
            return await base.ScalarExecutedAsync(command, eventData, result, cancellationToken);
        }

        public override async ValueTask<int> NonQueryExecutedAsync(DbCommand command, CommandExecutedEventData eventData, int result, CancellationToken cancellationToken = default)
        {
            LogDb(eventData, command, result);
            return await base.NonQueryExecutedAsync(command, eventData, result, cancellationToken);
        }

        private static int? Rows(DbDataReader r) => r?.RecordsAffected >= 0 ? r.RecordsAffected : null;

        private void LogDb(CommandExecutedEventData e, DbCommand cmd, int? rows)
        {
            var ms = e.Duration.TotalMilliseconds;
            string? sampledSql = null;
            if (_sampleSql && _rng.NextDouble() < _sampleRate)
            {
                sampledSql = cmd.CommandText; // TODO: redact if needed
            }

            Log.ForContext("Event", "Db.CommandExecuted")
               .ForContext("DurationMs", ms)
               .ForContext("Database", cmd.Connection?.Database)
               .ForContext("Command", e.CommandSource.ToString())
               .ForContext("RowCount", rows)
               .ForContext("SampledSql", sampledSql)
               .Information("DB command executed");
        }
    }
}
