using System;

namespace RWA.Web.Application.Services.Logging
{
    /// <summary>
    /// Stores the current WorkflowRunId in-memory (singleton). On app restart, a new id is generated
    /// until the first 'Reset Workflow' or external persistence sets it explicitly.
    /// Persisting the run id into DB is optional; you can adapt this provider to read/write there.
    /// </summary>
    public class WorkflowRunIdProvider : IWorkflowRunIdProvider
    {
        private string _current = Guid.NewGuid().ToString("n");
        public string GetCurrentRunId() => _current;
        public string NewRunId() => _current = Guid.NewGuid().ToString("n");
    }
}
