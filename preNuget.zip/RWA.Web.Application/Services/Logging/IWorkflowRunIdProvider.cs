namespace RWA.Web.Application.Services.Logging
{
    public interface IWorkflowRunIdProvider
    {
        /// <summary>Returns the current WorkflowRunId used to partition logs per workflow run.</summary>
        string GetCurrentRunId();
        /// <summary>Creates and sets a new WorkflowRunId (call this on 'Reset Workflow').</summary>
        string NewRunId();
    }
}
