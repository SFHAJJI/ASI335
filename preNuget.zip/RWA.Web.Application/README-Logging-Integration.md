# Per-Run Logging Pack — Integration Guide

This pack gives you:
- Per-run log partitioning (WorkflowRunId)
- Safe middlewares (SSE/SignalR not broken)
- EF Core command interceptor (durations, rows, sampled SQL opt-in)
- Typed domain events (LogWorkflow)
- Logs Controller (tail/stream/download)
- Summary generator stub
- Frontend snippets

## 1) Add files to your solution

Copy the `RWA.Web.Application` subfolders into your web project, keeping the folder structure:
  - Middleware/
  - Controllers/
  - Services/Logging/
  - Extensions/
  - docs/

## 2) Program.cs

```csharp
using RWA.Web.Application.Extensions;
using RWA.Web.Application.Services.Logging;
using RWA.Web.Application.Middleware;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

LoggingSetupExtensions.ConfigureSerilog(builder, enableFanOutFiles: true);
builder.Services.AddWorkflowLoggingServices();

builder.Services.AddDbContext<RwaContext>((sp, options) => {
    var interceptor = sp.GetRequiredService<DbCommandLoggingInterceptor>();
    options.AddInterceptors(interceptor);
});

var app = builder.Build();

app.UseWorkflowLogging();     // request logging + correlation + safe unified logging

app.UseWebSockets();
app.MapHub<WorkflowHub>("/workflowHub");

app.MapControllers();
app.Run();
```

## 3) Reset Workflow → new run id
Call `IWorkflowRunIdProvider.NewRunId()` when the Reset action occurs.

## 4) Where to find logs
- Global: `logs/app/app.jsonl`
- Per run (new folder each Reset): `logs/workflows/{WorkflowRunId}/workflow.jsonl` (+ `summary.md` etc.)

## 5) Endpoints
- `GET /api/logs/current/tail?lines=500`
- `GET /api/logs/current/stream` (Server-Sent Events; SignalR-safe)
- `GET /api/logs/{runId}/download`

## 6) Next steps
- Call `LogWorkflow.*` helpers from your state machine, background jobs, and controllers.
- Expand `RunSummaryGenerator` to compute p95s, N+1, SignalR chatter, and render a Mermaid state diagram.
```
