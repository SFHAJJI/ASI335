using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Serilog;

using Serilog.Context;
using RWA.Web.Application.Services.Logging;

namespace RWA.Web.Application.Middleware
{
    /// <summary>
    /// Attaches correlation properties (WorkflowRunId, SessionId, Actor) to the Serilog LogContext
    /// and echoes the WorkflowRunId back to the client. Keep this early in the pipeline.
    /// </summary>
    public sealed class CorrelationMiddleware
    {
        private readonly RequestDelegate _next;
        public CorrelationMiddleware(RequestDelegate next) => _next = next;

        public async Task Invoke(HttpContext ctx, IWorkflowRunIdProvider run)
        {
            var runId = ctx.Request.Headers["X-Workflow-Run-Id"].FirstOrDefault() ?? run.GetCurrentRunId();
            var sessionId = ctx.Request.Headers["X-Session-Id"].FirstOrDefault() ?? ctx.TraceIdentifier;

            using (LogContext.PushProperty("WorkflowRunId", runId))
            using (LogContext.PushProperty("SessionId", sessionId))
            using (LogContext.PushProperty("Actor", "api"))
            {
                ctx.Response.Headers["X-Workflow-Run-Id"] = runId;
                await _next(ctx);
            }
        }
    }
}
