using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace RWA.Web.Application.Middleware
{
    /// <summary>
    /// A safe place to do request/response logging for NORMAL requests.
    /// It intentionally skips SignalR/WebSockets and SSE endpoints so we don't break handshakes or streams.
    /// </summary>
    public class UnifiedLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private static readonly string[] ExcludeStartsWith = new[] { "/workflowHub" };

        public UnifiedLoggingMiddleware(RequestDelegate next) => _next = next;

        public async Task Invoke(HttpContext context)
        {
            // Skip WebSocket upgrade (SignalR)
            if (context.WebSockets.IsWebSocketRequest) { await _next(context); return; }

            // Skip SSE
            var accept = context.Request.Headers["Accept"].ToString();
            if (!string.IsNullOrEmpty(accept) && accept.Contains("text/event-stream", StringComparison.OrdinalIgnoreCase))
            {
                await _next(context); return;
            }

            // Skip negotiate/hub paths
            var path = context.Request.Path.Value ?? string.Empty;
            if (path.EndsWith("/negotiate", StringComparison.OrdinalIgnoreCase) ||
                ExcludeStartsWith.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
            {
                await _next(context); return;
            }

            // Normal requests: you may add minimal metadata logging here if needed.
            await _next(context);
        }
    }
}
