using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RWA.Web.Application.Services.Logging;

namespace RWA.Web.Application.Controllers
{
    [ApiController]
    [Route("api/logs")]
    public class LogsController : ControllerBase
    {
        private readonly IWorkflowRunIdProvider _run;
        public LogsController(IWorkflowRunIdProvider run) => _run = run;

        [HttpGet("current/tail")]
        public IActionResult Tail([FromQuery] int lines = 500)
        {
            var path = Path.Combine("logs","workflows", _run.GetCurrentRunId(), "workflow.jsonl");
            if (!System.IO.File.Exists(path)) return NotFound();
            var all = System.IO.File.ReadAllLines(path);
            var take = all.Length <= lines ? all : all[^lines..];
            return Content(string.Join('\n', take), "text/plain");
        }

        [HttpGet("current/stream")]
        public async Task Stream()
        {
            Response.Headers.Add("Content-Type", "text/event-stream");
            var path = Path.Combine("logs","workflows", _run.GetCurrentRunId(), "workflow.jsonl");
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            using var fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(fs);
            while (!HttpContext.RequestAborted.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync();
                if (line is null) { await Task.Delay(300, HttpContext.RequestAborted).ContinueWith(_=>{}); continue; }
                await Response.WriteAsync($"data: {line}\n\n");
                await Response.Body.FlushAsync();
            }
        }

        [HttpGet("{runId}/download")]
        public IActionResult Download(string runId)
        {
            var folder = Path.Combine("logs","workflows", runId);
            if (!Directory.Exists(folder)) return NotFound();
            var zipPath = Path.Combine(Path.GetTempPath(), $"logs-{runId}.zip");
            if (System.IO.File.Exists(zipPath)) System.IO.File.Delete(zipPath);
            ZipFile.CreateFromDirectory(folder, zipPath);
            return PhysicalFile(zipPath, "application/zip", Path.GetFileName(zipPath));
        }
    }
}
