using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;
using Serilog.Core;
using RWA.Web.Application.Services.Logging;
using RWA.Web.Application.Middleware;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace RWA.Web.Application.Extensions
{
    /// <summary>
    /// One-stop wiring for the logging pack. Call ConfigureSerilog(builder) early; call UseWorkflowLogging(app) in pipeline.
    /// Remember to add the DbCommandLoggingInterceptor to your DbContext via AddInterceptors(...).
    /// </summary>
    public static class LoggingSetupExtensions
    {
        public static void ConfigureSerilog(WebApplicationBuilder builder, bool enableFanOutFiles = true)
        {
            var compact = new CompactJsonFormatter();
            builder.Host.UseSerilog((ctx, cfg) =>
            {
                cfg.MinimumLevel.Information()
                  .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                  .Enrich.FromLogContext()

                  // Global application log
                  .WriteTo.Async(a => a.File(compact, "logs/app/app.jsonl",
                                    rollingInterval: RollingInterval.Day, shared: true))

                  // Per-run main narrative
                  .WriteTo.Async(a => a.Map("WorkflowRunId", "no-run",
                      (runId, wt) => wt.File(compact, $"logs/workflows/{runId}/workflow.jsonl",
                         rollingInterval: RollingInterval.Day, shared: true)));

                if (enableFanOutFiles)
                {
                    // Errors lens
                    cfg.WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(evt => evt.Level >= LogEventLevel.Warning)
                        .WriteTo.Map("WorkflowRunId", "no-run",
                            (runId, wt) => wt.File(compact, $"logs/workflows/{runId}/workflow.errors.jsonl",
                                rollingInterval: RollingInterval.Day, shared: true)));

                    // API lens
                    cfg.WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(evt =>
                            evt.Properties.TryGetValue("Event", out var val) &&
                            val is Serilog.Events.ScalarValue sv &&
                            sv.Value is string s && s.StartsWith("Api.", System.StringComparison.Ordinal))
                        .WriteTo.Map("WorkflowRunId", "no-run",
                            (runId, wt) => wt.File(compact, $"logs/workflows/{runId}/workflow.api.jsonl",
                                rollingInterval: RollingInterval.Day, shared: true)));

                    // DB lens
                    cfg.WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(evt =>
                            evt.Properties.TryGetValue("Event", out var val) &&
                            val is Serilog.Events.ScalarValue sv &&
                            sv.Value is string s && s.StartsWith("Db.", System.StringComparison.Ordinal))
                        .WriteTo.Map("WorkflowRunId", "no-run",
                            (runId, wt) => wt.File(compact, $"logs/workflows/{runId}/workflow.db.jsonl",
                                rollingInterval: RollingInterval.Day, shared: true)));

                    // SignalR lens
                    cfg.WriteTo.Logger(lc => lc
                        .Filter.ByIncludingOnly(evt =>
                            evt.Properties.TryGetValue("Event", out var val) &&
                            val is Serilog.Events.ScalarValue sv &&
                            sv.Value is string s && s.StartsWith("Workflow.SignalR", System.StringComparison.Ordinal))
                        .WriteTo.Map("WorkflowRunId", "no-run",
                            (runId, wt) => wt.File(compact, $"logs/workflows/{runId}/workflow.signalr.jsonl",
                                rollingInterval: RollingInterval.Day, shared: true)));
                }
            });
        }

        public static void AddWorkflowLoggingServices(this IServiceCollection services)
        {
            services.AddSingleton<IWorkflowRunIdProvider, WorkflowRunIdProvider>();
            services.AddSingleton<DbCommandLoggingInterceptor>(sp => new DbCommandLoggingInterceptor(
                sampleSql: false, sampleRate: 0.02));
            services.AddSingleton<RunSummaryGenerator>();
        }

        public static void UseWorkflowLogging(this WebApplication app)
        {
            app.UseSerilogRequestLogging();
            app.UseMiddleware<CorrelationMiddleware>();
            app.UseMiddleware<UnifiedLoggingMiddleware>();
            // Keep UseWebSockets and SignalR hub mapping after this.
        }
    }
}
