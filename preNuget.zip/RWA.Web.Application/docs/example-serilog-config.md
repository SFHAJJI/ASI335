# Example Serilog Configuration (Program.cs)

using RWA.Web.Application.Extensions;
using RWA.Web.Application.Services.Logging;
using RWA.Web.Application.Middleware;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 1) Configure Serilog sinks (global + per-run + optional fan-out)
LoggingSetupExtensions.ConfigureSerilog(builder, enableFanOutFiles: true);

// 2) Services for logging
builder.Services.AddWorkflowLoggingServices();

// 3) Register EF Core DbContext with the logging interceptor
builder.Services.AddDbContext<RwaContext>((sp, options) =>
{
    var interceptor = sp.GetRequiredService<DbCommandLoggingInterceptor>();
    options.AddInterceptors(interceptor);
    // other options...
});

var app = builder.Build();

// 4) Pipeline: request logging, correlation, safe unified logging
app.UseWorkflowLogging();

// 5) WebSockets + SignalR hubs AFTER logging middlewares
app.UseWebSockets();
app.MapHub<WorkflowHub>("/workflowHub");

app.MapControllers();
app.Run();
