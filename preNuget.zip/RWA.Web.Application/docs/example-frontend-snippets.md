# Frontend snippets (Vue 3)

## Axios correlation headers
```ts
import axios from 'axios';
const http = axios.create();
http.interceptors.request.use(cfg => {
  const runId = localStorage.getItem('workflowRunId') || '';
  const s = sessionStorage.getItem('sessionId') ||
            (sessionStorage.setItem('sessionId', crypto.randomUUID()), sessionStorage.getItem('sessionId'));
  cfg.headers['X-Workflow-Run-Id'] = runId;
  cfg.headers['X-Session-Id'] = s!;
  return cfg;
});
export default http;
```

## SignalR connection with run id
```ts
import * as signalR from '@microsoft/signalr';
export function connect(runId: string) {
  return new signalR.HubConnectionBuilder()
    .withUrl(`/workflowHub?runId=${encodeURIComponent(runId)}`)
    .withAutomaticReconnect()
    .build();
}
```

## SSE log tail (admin)
```ts
export function streamLogs() {
  const ev = new EventSource('/api/logs/current/stream');
  ev.onmessage = (e) => { console.log('LOG', e.data); };
  ev.onerror = () => ev.close();
  return ev;
}
```
