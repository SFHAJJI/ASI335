# Logging Legend (Event Dictionary)

Common fields on every log record:
- WorkflowRunId, TraceId, SpanId, RequestId, SessionId
- Actor (ui|api|worker), Component
- Event, Level, Timestamp
- Optional metrics: DurationMs, SizeBytes, Count, RowCount

Event families:
- Workflow.StepEntered / Workflow.StepExited
- Workflow.TransitionTriggered
- Workflow.BackgroundJobEnqueued
- Workflow.SignalRProgress
- Workflow.TethysStatusRun
- Workflow.BddMatchBatch
- Api.RequestSummary
- Db.CommandExecuted
- Cache.Hit / Cache.Miss
- Exceptions (same envelope, with exception info)
